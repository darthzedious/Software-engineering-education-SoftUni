from project.hero import Hero

class Knight(Hero):
    pass


kn = Knight("A", 99)
print(str(kn))