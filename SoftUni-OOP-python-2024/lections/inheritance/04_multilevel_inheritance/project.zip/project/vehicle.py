class Vehicle:
    def move(self):
        return f"moving..."
